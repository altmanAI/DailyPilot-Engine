# DailyPilot-Engine – API Notes

Python reference usage:

```python
from engine.core.models import Task, ProfileConfig
from engine.core.scoring import score_tasks
from engine.core.selectors import build_daily_plan
```
