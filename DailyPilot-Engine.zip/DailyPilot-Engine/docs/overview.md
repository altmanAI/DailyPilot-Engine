# DailyPilot-Engine – Overview

DailyPilot-Engine is the prioritization core of DailyPilot by AltmanAI.

It exists to answer one question for a human: **What should I realistically focus on today?**
