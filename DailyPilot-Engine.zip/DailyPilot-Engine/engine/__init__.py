"""DailyPilot-Engine core package."""
